import { Component, OnInit } from '@angular/core';
import { TodoList } from './todoList';
import { TodoService } from './todo-list.service'
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-todo-list',
  templateUrl: './todo-list.component.html',
  styleUrls: ['./todo-list.component.css']
})

export class TodoListComponent implements OnInit {
  todoList:TodoList;
  todoListing: TodoList[];
  selectedAll: any;

  constructor(private todoService: TodoService) {
    this.todoList=new TodoList();
 this.todoListing=[];
   }

  ngOnInit() {
    this.getTodoList();
  }

  getTodoList():void {
    this.todoListing=this.todoService.getAllTodoList();
  }

  addTodoList():void {
    let todoList = this.todoList;
    todoList.isDeleted=false;
    todoList.createdDate=new Date();
   this.todoListing=this.todoService.addTodoList(todoList);

   if(this.selectedAll )
   {
    this.selectAll();
   }
   this.todoList=new TodoList();
  }

  deleteTodoList():void {
 
   this.todoListing=this.todoService.deleteTodoList(this.todoListing);
  }

  selectAll() {
    debugger;
    for (var i = 0; i <= this.todoListing.length; i++) {
      this.todoListing[i].isDeleted = this.selectedAll;
    }
  }

  checkIfAllSelected() {
    this.selectedAll = this.todoListing.every(function(item:any) {
        return item.isDeleted == true;
      })
  }
}
