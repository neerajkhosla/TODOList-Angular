export class TodoList {
    id: String;
    taskName: String;
    taskDesc: String;
    createdDate:Date;
    isDeleted:Boolean;
    isCompleted:Boolean;
}