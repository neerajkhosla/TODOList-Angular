import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { TodoList } from './todoList';
import { Http } from '@angular/http';

export class TodoService {

    constructor() { 
    }

    // get all to-do list
    getAllTodoList():TodoList[] {
        let todoListdata=localStorage.getItem("todoListArray");
        return JSON.parse(todoListdata) as TodoList[];
    }

    //add to-do list
    addTodoList(todoList: TodoList):TodoList[] {
        // Save TodoList in local storage
        let todoListdata=localStorage.getItem("todoListArray");
        let todoArray=[]; 
        if(todoListdata)
        {
            todoArray =JSON.parse(todoListdata) as TodoList[];
        }
        todoArray.push(todoList);
        localStorage.setItem("todoListArray",JSON.stringify(todoArray));
        let todoListArrayData=localStorage.getItem("todoListArray");
        return JSON.parse(todoListArrayData) as TodoList[];
    }

     //delete to-do list
     deleteTodoList(todoListing: TodoList[]):TodoList[] {
    
        for (var i = 0; i < todoListing.length; i++) {
            if(todoListing[i].isDeleted)
            {
            todoListing.splice(i,1);
            }
          }
        localStorage.setItem("todoListArray",JSON.stringify(todoListing));
        let todoListArrayData=localStorage.getItem("todoListArray");
        return JSON.parse(todoListArrayData) as TodoList[];
     }
}